python train.py  --dataset  ped2  --train_folder  ../Data/ped2/training/frames --test_folder  ../Data/ped2/testing/frames --gpu  0 --iters    10000


#python inference.py  --dataset  ped2  --train_folder  ../Data/ped2/training/frames --test_folder  ../Data/ped2/testing/frames --gpu  0 --iters    80000
